import request

# import os
from datetime import datetime
Api_key="85ee295a735758a2fc95c35a4b3e00c3"
location=input("Enter the city name: ")
complete_api_link="https:api.openweathermap.org/data/2.5/weather?q"+location+"&appid_key"
api_link=request.get(complete_api_link)
api_data=api_link.json()

#create variables to store and display data
temp_city=((api_data['main']['temp'])-273.15)
weather_desc=api_data['weather'][0]['description']
hmdt=api_data['main']['humidity']
wind_spd=api_data['wind']['speed']
date_time=datatime.now().strftime ("%d %b %y | %I: %M: %S: %P")

print("----------------------------------")
print("weather stats for - {} || {}".format location.Upper(),date_time)
print("----------------------------------")

print("current temperature is: {:.2f} deg C".format(temp_city))
Print("current weather desc: ",weather_desc)
print("current Humidity:",hmdt, '%')
print("current wind speed:",wind_spd,'kmph'
)

print("----------------------------------")

#making a list so that i can print the info to a txt
txt list=[temp_city,weather_desc,hmdt,wind_spd,date_time]

#using open() built-in function to write a text file
with open("textfile.txt,mode="H",encoding='UTF-8') as f:
                 #encoding=UTF-8for linux
f.write("-----------------------------\n")
f.write("weather starts for - {} || {}".format (location.upper(),date_time))
f.write("\n--------------------------\n")
f.write("current temperature is: {:.2f} deg c\n".format(txtlist[0]))
f.write("{},{}\n".format("current weather desc:"))
f.write("{},{},{}\n".format("current Humidity:",txtlist[2],"%"))
f.write("{},{},{}\n".format("current speed:"txtlist[3],"kmph"))

f.write("=============================")






























































































